import streamlit as st
import pandas as pd
import numpy as np
import time
import random
import io
import traceback
from datetime import datetime

# ── Page config ────────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="SQL Engine Benchmark Dashboard",
    page_icon="⚡",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Custom CSS ──────────────────────────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;700&family=Syne:wght@400;600;800&display=swap');

html, body, [class*="css"] {
    font-family: 'Syne', sans-serif;
}
code, pre, .stCode {
    font-family: 'JetBrains Mono', monospace !important;
}

/* Dark industrial theme */
.stApp {
    background-color: #0d0f14;
    color: #e8e8e8;
}

.main .block-container {
    padding-top: 1.5rem;
    padding-bottom: 2rem;
}

/* Header */
.dash-header {
    background: linear-gradient(135deg, #0d0f14 0%, #141820 50%, #0d0f14 100%);
    border-bottom: 1px solid #2a2f3d;
    padding: 1.5rem 0 1rem 0;
    margin-bottom: 1.5rem;
}
.dash-title {
    font-size: 2.4rem;
    font-weight: 800;
    letter-spacing: -0.03em;
    background: linear-gradient(90deg, #00e5ff, #7c3aed, #f59e0b);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    line-height: 1.1;
}
.dash-subtitle {
    color: #6b7a99;
    font-size: 0.95rem;
    margin-top: 0.4rem;
    letter-spacing: 0.05em;
    text-transform: uppercase;
}

/* Metric cards */
.metric-card {
    background: #141820;
    border: 1px solid #252a38;
    border-radius: 10px;
    padding: 1.1rem 1.3rem;
    position: relative;
    overflow: hidden;
    transition: border-color 0.2s;
}
.metric-card:hover { border-color: #00e5ff55; }
.metric-card::before {
    content: '';
    position: absolute;
    top: 0; left: 0; right: 0;
    height: 2px;
    background: linear-gradient(90deg, #00e5ff, #7c3aed);
}
.metric-label {
    color: #6b7a99;
    font-size: 0.75rem;
    text-transform: uppercase;
    letter-spacing: 0.1em;
    margin-bottom: 0.3rem;
}
.metric-value {
    font-size: 2rem;
    font-weight: 800;
    color: #e8e8e8;
    font-family: 'JetBrains Mono', monospace;
    line-height: 1;
}
.metric-unit {
    font-size: 0.85rem;
    color: #6b7a99;
    margin-left: 0.3rem;
}
.metric-delta {
    font-size: 0.8rem;
    margin-top: 0.4rem;
}
.delta-good { color: #22c55e; }
.delta-bad  { color: #ef4444; }

/* Engine badge */
.engine-badge {
    display: inline-block;
    padding: 2px 10px;
    border-radius: 20px;
    font-size: 0.75rem;
    font-weight: 600;
    letter-spacing: 0.05em;
    font-family: 'JetBrains Mono', monospace;
}

/* Section headers */
.section-header {
    font-size: 0.7rem;
    text-transform: uppercase;
    letter-spacing: 0.15em;
    color: #6b7a99;
    border-bottom: 1px solid #252a38;
    padding-bottom: 0.5rem;
    margin-bottom: 1rem;
    font-weight: 600;
}

/* Result table */
.stDataFrame { background: #141820 !important; }

/* Sidebar */
section[data-testid="stSidebar"] {
    background-color: #0a0c10 !important;
    border-right: 1px solid #1e2330;
}
section[data-testid="stSidebar"] .stMarkdown h3 {
    color: #00e5ff;
    font-size: 0.7rem;
    text-transform: uppercase;
    letter-spacing: 0.15em;
}

/* Status pills */
.status-ok   { color: #22c55e; }
.status-warn { color: #f59e0b; }
.status-err  { color: #ef4444; }
.status-skip { color: #6b7a99; }

/* Code block */
.query-box {
    background: #0a0c10;
    border: 1px solid #252a38;
    border-left: 3px solid #7c3aed;
    border-radius: 6px;
    padding: 1rem;
    font-family: 'JetBrains Mono', monospace;
    font-size: 0.82rem;
    color: #c4b5fd;
    white-space: pre-wrap;
    overflow-x: auto;
}

/* Log */
.log-box {
    background: #0a0c10;
    border: 1px solid #1e2330;
    border-radius: 6px;
    padding: 0.8rem;
    font-family: 'JetBrains Mono', monospace;
    font-size: 0.78rem;
    color: #6b7a99;
    max-height: 260px;
    overflow-y: auto;
}
.log-ok   { color: #22c55e; }
.log-err  { color: #ef4444; }
.log-info { color: #00e5ff; }
.log-warn { color: #f59e0b; }

/* Progress bar override */
.stProgress > div > div > div { background: linear-gradient(90deg, #00e5ff, #7c3aed) !important; }

/* Button */
.stButton > button {
    background: linear-gradient(135deg, #7c3aed, #00e5ff22);
    border: 1px solid #7c3aed;
    color: #e8e8e8;
    font-family: 'Syne', sans-serif;
    font-weight: 600;
    letter-spacing: 0.05em;
    border-radius: 6px;
    padding: 0.5rem 1.5rem;
    transition: all 0.2s;
}
.stButton > button:hover {
    border-color: #00e5ff;
    background: linear-gradient(135deg, #7c3aed88, #00e5ff22);
}

/* Selectbox, multiselect */
.stSelectbox label, .stMultiSelect label, .stSlider label, .stCheckbox label {
    color: #9ca3af !important;
    font-size: 0.8rem !important;
    text-transform: uppercase;
    letter-spacing: 0.08em;
}

/* Tabs */
.stTabs [data-baseweb="tab-list"] {
    background: transparent;
    border-bottom: 1px solid #252a38;
    gap: 0;
}
.stTabs [data-baseweb="tab"] {
    color: #6b7a99 !important;
    font-family: 'Syne', sans-serif;
    font-size: 0.82rem;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    padding: 0.5rem 1.2rem;
    border-bottom: 2px solid transparent;
}
.stTabs [aria-selected="true"] {
    color: #00e5ff !important;
    border-bottom: 2px solid #00e5ff !important;
    background: transparent !important;
}
</style>
""", unsafe_allow_html=True)

# ── Engine Definitions ──────────────────────────────────────────────────────────
ENGINES = {
    "PySpark":     {"color": "#f97316", "bg": "#f9731622", "icon": "🔥", "pkg": "pyspark"},
    "DuckDB":      {"color": "#facc15", "bg": "#facc1522", "icon": "🦆", "pkg": "duckdb"},
    "Dask-SQL":    {"color": "#a78bfa", "bg": "#a78bfa22", "icon": "⚙️", "pkg": "dask_sql"},
    "SQLAlchemy":  {"color": "#34d399", "bg": "#34d39922", "icon": "🔗", "pkg": "sqlalchemy"},
    "psycopg2":    {"color": "#60a5fa", "bg": "#60a5fa22", "icon": "🐘", "pkg": "psycopg2"},
    "Polars":      {"color": "#f43f5e", "bg": "#f43f5e22", "icon": "🐻‍❄️", "pkg": "polars"},
}

QUERY_TEMPLATES = {
    "Count Records":
        "SELECT COUNT(*) AS total_records\nFROM {table}",
    "Top Counties by Gross Income":
        "SELECT \"County\", SUM(\"NY_AGI_FDAP\") AS total_agi\nFROM {table}\nGROUP BY \"County\"\nORDER BY total_agi DESC\nLIMIT 10",
    "Income Bracket Distribution":
        "SELECT \"Tax_Liability_Status\", COUNT(*) AS cnt,\n       AVG(\"NY_AGI_FDAP\") AS avg_agi\nFROM {table}\nGROUP BY \"Tax_Liability_Status\"",
    "Null Audit":
        "SELECT COUNT(*) AS total,\n       COUNT(\"County\") AS has_county,\n       COUNT(\"NY_AGI_FDAP\") AS has_agi\nFROM {table}",
    "Custom SQL": "",
}

# ── Sample data generator ───────────────────────────────────────────────────────
@st.cache_data
def load_nys_sample(n_rows: int = 50_000) -> pd.DataFrame:
    """Generate synthetic NYS Tax-like data."""
    rng = np.random.default_rng(42)
    counties = [
        "Albany","Bronx","Brooklyn","Buffalo","Chautauqua","Erie",
        "Kings","Manhattan","Nassau","New York","Niagara","Oneida",
        "Onondaga","Orange","Queens","Richmond","Rockland","Suffolk",
        "Ulster","Westchester",
    ]
    brackets = ["No Tax Liability","Tax Liability","Refund Only","Part-Year","Non-Resident"]
    filing   = ["Single","Married Joint","Married Separate","Head of Household"]

    df = pd.DataFrame({
        "Tax_Year":            rng.choice([2019,2020,2021,2022,2023], n_rows),
        "County":              rng.choice(counties, n_rows),
        "NY_AGI_FDAP":         rng.lognormal(11, 1.2, n_rows).round(2),
        "Tax_Liability_Status":rng.choice(brackets, n_rows),
        "Filing_Status":       rng.choice(filing, n_rows),
        "Num_Exemptions":      rng.integers(0, 8, n_rows),
        "Tax_Before_Credits":  rng.lognormal(9, 1.5, n_rows).round(2),
        "STAR_Credit":         rng.choice([0,0,0,500,1000,1500], n_rows, p=[.55,.15,.1,.1,.05,.05]),
        "Child_Credit":        rng.choice([0,500,1000,2000], n_rows, p=[.5,.2,.2,.1]),
        "Net_Tax_Due":         rng.lognormal(8, 1.8, n_rows).round(2),
    })
    return df

# ── Engine runners ──────────────────────────────────────────────────────────────
def run_duckdb(df: pd.DataFrame, sql: str) -> tuple[pd.DataFrame, float, str]:
    try:
        import duckdb
        t0 = time.perf_counter()
        con = duckdb.connect()
        con.register("nys_tax", df)
        result = con.execute(sql.replace("{table}", "nys_tax")).df()
        elapsed = time.perf_counter() - t0
        return result, elapsed, "ok"
    except ImportError:
        return pd.DataFrame(), 0, "not_installed"
    except Exception as e:
        return pd.DataFrame(), 0, str(e)

def run_polars(df: pd.DataFrame, sql: str) -> tuple[pd.DataFrame, float, str]:
    try:
        import polars as pl
        t0 = time.perf_counter()
        ldf = pl.from_pandas(df).lazy()
        ctx = pl.SQLContext(nys_tax=ldf, eager=True)
        result = ctx.execute(sql.replace("{table}", "nys_tax")).to_pandas()
        elapsed = time.perf_counter() - t0
        return result, elapsed, "ok"
    except ImportError:
        return pd.DataFrame(), 0, "not_installed"
    except Exception as e:
        return pd.DataFrame(), 0, str(e)

def run_sqlalchemy(df: pd.DataFrame, sql: str) -> tuple[pd.DataFrame, float, str]:
    try:
        from sqlalchemy import create_engine, text
        t0 = time.perf_counter()
        engine = create_engine("sqlite:///:memory:", future=True)
        df.to_sql("nys_tax", engine, index=False, if_exists="replace")
        with engine.connect() as con:
            result = pd.read_sql(text(sql.replace("{table}", "nys_tax")), con)
        elapsed = time.perf_counter() - t0
        return result, elapsed, "ok"
    except ImportError:
        return pd.DataFrame(), 0, "not_installed"
    except Exception as e:
        return pd.DataFrame(), 0, str(e)

def run_psycopg2(df: pd.DataFrame, sql: str) -> tuple[pd.DataFrame, float, str]:
    try:
        import psycopg2
        return pd.DataFrame(), 0, "requires_postgres"
    except ImportError:
        return pd.DataFrame(), 0, "not_installed"

def run_pyspark(df: pd.DataFrame, sql: str) -> tuple[pd.DataFrame, float, str]:
    try:
        from pyspark.sql import SparkSession
        t0 = time.perf_counter()
        spark = (SparkSession.builder
                 .master("local[*]")
                 .appName("BenchDash")
                 .config("spark.ui.showConsoleProgress", "false")
                 .getOrCreate())
        spark.sparkContext.setLogLevel("ERROR")
        sdf = spark.createDataFrame(df)
        sdf.createOrReplaceTempView("nys_tax")
        result = spark.sql(sql.replace("{table}", "nys_tax")).toPandas()
        elapsed = time.perf_counter() - t0
        return result, elapsed, "ok"
    except ImportError:
        return pd.DataFrame(), 0, "not_installed"
    except Exception as e:
        return pd.DataFrame(), 0, str(e)

def run_dask_sql(df: pd.DataFrame, sql: str) -> tuple[pd.DataFrame, float, str]:
    try:
        import dask.dataframe as dd
        from dask_sql import Context
        t0 = time.perf_counter()
        ddf = dd.from_pandas(df, npartitions=4)
        ctx = Context()
        ctx.create_table("nys_tax", ddf)
        result = ctx.sql(sql.replace("{table}", "nys_tax")).compute()
        elapsed = time.perf_counter() - t0
        return result, elapsed, "ok"
    except ImportError:
        return pd.DataFrame(), 0, "not_installed"
    except Exception as e:
        return pd.DataFrame(), 0, str(e)

ENGINE_RUNNERS = {
    "DuckDB":     run_duckdb,
    "Polars":     run_polars,
    "SQLAlchemy": run_sqlalchemy,
    "psycopg2":   run_psycopg2,
    "PySpark":    run_pyspark,
    "Dask-SQL":   run_dask_sql,
}

STATUS_LABELS = {
    "ok":               ("✓ OK",           "status-ok"),
    "not_installed":    ("✗ Not Installed", "status-skip"),
    "requires_postgres":("⚠ Needs Postgres","status-warn"),
    "skip":             ("– Skipped",       "status-skip"),
}

def status_html(code: str) -> str:
    label, css = STATUS_LABELS.get(code, (f"✗ {code[:20]}", "status-err"))
    return f'<span class="{css}">{label}</span>'

def engine_badge(name: str) -> str:
    cfg = ENGINES[name]
    return (f'<span class="engine-badge" '
            f'style="background:{cfg["bg"]};color:{cfg["color"]};'
            f'border:1px solid {cfg["color"]}55;">'
            f'{cfg["icon"]} {name}</span>')

# ── Sidebar ─────────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("### ⚡ Configuration")
    st.divider()

    st.markdown("### Dataset")
    data_source = st.radio(
        "Source",
        ["NYS Tax Sample (built-in)", "Upload CSV / Parquet"],
        label_visibility="collapsed",
    )

    uploaded_df = None
    table_name  = "nys_tax"

    if data_source == "Upload CSV / Parquet":
        up = st.file_uploader("Upload file", type=["csv", "parquet", "tsv"])
        if up:
            try:
                if up.name.endswith(".parquet"):
                    uploaded_df = pd.read_parquet(up)
                else:
                    uploaded_df = pd.read_csv(up)
                table_name = up.name.split(".")[0]
                st.success(f"Loaded {len(uploaded_df):,} rows")
            except Exception as e:
                st.error(f"Read error: {e}")
    
    n_rows = st.slider("Sample size (built-in)", 10_000, 200_000, 50_000, 10_000,
                       help="Rows in generated NYS Tax dataset")

    st.divider()
    st.markdown("### Engines")
    selected_engines = st.multiselect(
        "Run with",
        list(ENGINES.keys()),
        default=["DuckDB", "Polars", "SQLAlchemy"],
    )

    st.divider()
    st.markdown("### Query")
    query_template = st.selectbox("Template", list(QUERY_TEMPLATES.keys()))
    runs_per_engine = st.slider("Runs per engine", 1, 5, 3,
                                help="Average over N runs for stable timing")

    st.divider()
    st.markdown("""
<div style="font-size:0.72rem;color:#3d4455;line-height:1.7;">
<b style="color:#6b7a99;">Engines</b><br>
🦆 DuckDB — in-process OLAP<br>
🐻‍❄️ Polars — Rust dataframe SQL<br>
🔗 SQLAlchemy — ORM/SQLite<br>
🐘 psycopg2 — PostgreSQL native<br>
🔥 PySpark — distributed JVM<br>
⚙️ Dask-SQL — parallel pandas<br><br>
<b style="color:#6b7a99;">Note</b><br>
PySpark & psycopg2 need extra<br>
runtime setup to benchmark.
</div>
""", unsafe_allow_html=True)

# ── Load Data ───────────────────────────────────────────────────────────────────
if uploaded_df is not None:
    df = uploaded_df
else:
    df = load_nys_sample(n_rows)

# ── Header ───────────────────────────────────────────────────────────────────────
st.markdown("""
<div class="dash-header">
  <div class="dash-title">SQL Engine Benchmark</div>
  <div class="dash-subtitle">PySpark · DuckDB · Dask-SQL · SQLAlchemy · psycopg2 · Polars — NYS Tax Data &amp; Beyond</div>
</div>
""", unsafe_allow_html=True)

# ── Overview metrics ─────────────────────────────────────────────────────────────
m1, m2, m3, m4 = st.columns(4)
with m1:
    st.markdown(f"""<div class="metric-card">
        <div class="metric-label">Dataset Rows</div>
        <div class="metric-value">{len(df):,}<span class="metric-unit">rows</span></div>
    </div>""", unsafe_allow_html=True)
with m2:
    st.markdown(f"""<div class="metric-card">
        <div class="metric-label">Columns</div>
        <div class="metric-value">{len(df.columns)}<span class="metric-unit">cols</span></div>
    </div>""", unsafe_allow_html=True)
with m3:
    mem_mb = df.memory_usage(deep=True).sum() / 1e6
    st.markdown(f"""<div class="metric-card">
        <div class="metric-label">Memory</div>
        <div class="metric-value">{mem_mb:.1f}<span class="metric-unit">MB</span></div>
    </div>""", unsafe_allow_html=True)
with m4:
    st.markdown(f"""<div class="metric-card">
        <div class="metric-label">Engines Selected</div>
        <div class="metric-value">{len(selected_engines)}<span class="metric-unit">/{len(ENGINES)}</span></div>
    </div>""", unsafe_allow_html=True)

st.markdown("<div style='margin-top:1.5rem'></div>", unsafe_allow_html=True)

# ── Tabs ─────────────────────────────────────────────────────────────────────────
tab_bench, tab_data, tab_schema, tab_guide = st.tabs([
    "⚡ Benchmark", "🗂 Data Preview", "🔬 Schema & Stats", "📖 Engine Guide"
])

# ══════════════════════════════════════════════════════════════════════════════════
# TAB 1 — BENCHMARK
# ══════════════════════════════════════════════════════════════════════════════════
with tab_bench:
    # SQL editor
    st.markdown('<div class="section-header">SQL Query</div>', unsafe_allow_html=True)
    base_sql = QUERY_TEMPLATES[query_template]
    if query_template == "Custom SQL":
        base_sql = f"SELECT * FROM {{table}} LIMIT 20"

    cols = [f'"{c}"' for c in df.columns]
    col_hint = ", ".join(cols[:5]) + ("..." if len(cols) > 5 else "")
    st.caption(f"Available columns: `{col_hint}` — use `{{table}}` as table placeholder")

    sql_query = st.text_area(
        "SQL",
        value=base_sql,
        height=110,
        label_visibility="collapsed",
    )

    run_col, _ = st.columns([1, 4])
    with run_col:
        run_btn = st.button("▶  Run Benchmark", use_container_width=True)

    if not selected_engines:
        st.warning("Select at least one engine from the sidebar.")
    elif run_btn:
        st.markdown('<div class="section-header" style="margin-top:1.2rem">Execution Log</div>',
                    unsafe_allow_html=True)

        log_lines   = []
        all_results = {}   # engine → {time, status, df}
        prog = st.progress(0)
        log_ph = st.empty()

        def render_log():
            html = "<div class='log-box'>" + "<br>".join(log_lines[-30:]) + "</div>"
            log_ph.markdown(html, unsafe_allow_html=True)

        for i, eng in enumerate(selected_engines):
            cfg = ENGINES[eng]
            times = []
            last_result, last_status = pd.DataFrame(), "skip"

            log_lines.append(
                f'<span class="log-info">[{datetime.now():%H:%M:%S}] '
                f'Starting {cfg["icon"]} {eng}  (×{runs_per_engine})</span>'
            )
            render_log()

            runner = ENGINE_RUNNERS.get(eng)
            if runner is None:
                last_status = "not_installed"
            else:
                for r in range(runs_per_engine):
                    result_df, elapsed, status = runner(df, sql_query)
                    if status == "ok":
                        times.append(elapsed)
                        last_result = result_df
                        last_status = "ok"
                        log_lines.append(
                            f'<span class="log-ok">  run {r+1}: {elapsed*1000:.1f} ms</span>'
                        )
                    else:
                        last_status = status
                        log_lines.append(
                            f'<span class="log-warn">  run {r+1}: {status}</span>'
                        )
                        break
                    render_log()

            avg_t = float(np.mean(times)) if times else None
            all_results[eng] = {
                "avg_ms": avg_t * 1000 if avg_t else None,
                "runs":   len(times),
                "status": last_status,
                "df":     last_result,
                "times":  [t * 1000 for t in times],
            }
            prog.progress((i + 1) / len(selected_engines))
            render_log()

        prog.empty()

        # ── Results summary table ─────────────────────────────────────────────
        st.markdown('<div class="section-header" style="margin-top:1.5rem">Results</div>',
                    unsafe_allow_html=True)

        # Timing leaderboard
        ok_engines = [(e, v) for e, v in all_results.items()
                      if v["status"] == "ok" and v["avg_ms"] is not None]
        ok_engines.sort(key=lambda x: x[1]["avg_ms"])

        if ok_engines:
            fastest_ms = ok_engines[0][1]["avg_ms"]

            lc, rc = st.columns([3, 2])
            with lc:
                # Bar chart via plotly
                try:
                    import plotly.graph_objects as go
                    eng_names  = [e for e, _ in ok_engines]
                    eng_times  = [v["avg_ms"] for _, v in ok_engines]
                    eng_colors = [ENGINES[e]["color"] for e in eng_names]

                    fig = go.Figure(go.Bar(
                        x=eng_times,
                        y=eng_names,
                        orientation="h",
                        marker_color=eng_colors,
                        marker_line_width=0,
                        text=[f"{t:.1f} ms" for t in eng_times],
                        textposition="outside",
                        textfont=dict(color="#e8e8e8", family="JetBrains Mono"),
                    ))
                    fig.update_layout(
                        paper_bgcolor="rgba(0,0,0,0)",
                        plot_bgcolor="rgba(0,0,0,0)",
                        margin=dict(l=0, r=80, t=10, b=10),
                        xaxis=dict(
                            showgrid=True, gridcolor="#1e2330",
                            color="#6b7a99", title="Avg latency (ms)",
                        ),
                        yaxis=dict(color="#e8e8e8", autorange="reversed"),
                        height=max(200, len(ok_engines) * 55),
                        font=dict(family="Syne"),
                    )
                    st.plotly_chart(fig, use_container_width=True)
                except ImportError:
                    st.info("Install plotly for bar charts: `pip install plotly`")

            with rc:
                for rank, (eng, v) in enumerate(ok_engines, 1):
                    cfg = ENGINES[eng]
                    speedup = v["avg_ms"] / fastest_ms
                    medal = ["🥇","🥈","🥉"][rank-1] if rank <= 3 else f"#{rank}"
                    st.markdown(f"""
<div class="metric-card" style="margin-bottom:0.6rem;border-color:{cfg['color']}44">
  <div style="display:flex;justify-content:space-between;align-items:center">
    <span style="font-size:1.1rem">{medal} {engine_badge(eng)}</span>
  </div>
  <div class="metric-value" style="color:{cfg['color']};font-size:1.5rem">
    {v['avg_ms']:.1f}<span class="metric-unit">ms</span>
  </div>
  <div class="metric-delta {'delta-good' if speedup==1 else 'delta-bad'}">
    {'fastest' if speedup==1 else f'{speedup:.1f}× slower'}
    · {v['runs']} run{'s' if v['runs']!=1 else ''}
  </div>
</div>""", unsafe_allow_html=True)

        # Status summary for all engines
        st.markdown('<div class="section-header" style="margin-top:1rem">All Engines</div>',
                    unsafe_allow_html=True)
        rows = []
        for eng, v in all_results.items():
            rows.append({
                "Engine": eng,
                "Status": v["status"],
                "Avg (ms)": f"{v['avg_ms']:.2f}" if v["avg_ms"] else "—",
                "Runs": v["runs"],
                "Result Rows": len(v["df"]) if not v["df"].empty else "—",
            })
        summary_df = pd.DataFrame(rows)
        st.dataframe(summary_df, use_container_width=True, hide_index=True)

        # ── Per-engine result previews ──────────────────────────────────────
        if ok_engines:
            st.markdown('<div class="section-header" style="margin-top:1.2rem">Query Result Previews</div>',
                        unsafe_allow_html=True)
            tabs_res = st.tabs([f"{ENGINES[e]['icon']} {e}" for e, _ in ok_engines])
            for tab_r, (eng, v) in zip(tabs_res, ok_engines):
                with tab_r:
                    st.dataframe(v["df"].head(20), use_container_width=True, hide_index=True)

        # ── Run distribution (box plot) ─────────────────────────────────────
        multi_run = [(e, v) for e, v in all_results.items()
                     if v["status"] == "ok" and len(v["times"]) > 1]
        if multi_run:
            try:
                import plotly.graph_objects as go
                fig2 = go.Figure()
                for eng, v in multi_run:
                    fig2.add_trace(go.Box(
                        y=v["times"],
                        name=eng,
                        marker_color=ENGINES[eng]["color"],
                        line_color=ENGINES[eng]["color"],
                        boxmean=True,
                    ))
                fig2.update_layout(
                    paper_bgcolor="rgba(0,0,0,0)",
                    plot_bgcolor="rgba(0,0,0,0)",
                    yaxis=dict(title="Latency (ms)", gridcolor="#1e2330", color="#6b7a99"),
                    xaxis=dict(color="#e8e8e8"),
                    margin=dict(l=0, r=0, t=20, b=10),
                    height=280,
                    showlegend=False,
                    font=dict(family="Syne"),
                )
                st.markdown('<div class="section-header" style="margin-top:1rem">Run Distribution</div>',
                            unsafe_allow_html=True)
                st.plotly_chart(fig2, use_container_width=True)
            except ImportError:
                pass

# ══════════════════════════════════════════════════════════════════════════════════
# TAB 2 — DATA PREVIEW
# ══════════════════════════════════════════════════════════════════════════════════
with tab_data:
    st.markdown('<div class="section-header">Dataset Preview</div>', unsafe_allow_html=True)

    fc1, fc2, fc3 = st.columns(3)
    with fc1:
        filter_county = st.selectbox(
            "Filter by County",
            ["All"] + (sorted(df["County"].unique().tolist())
                       if "County" in df.columns else []),
        )
    with fc2:
        n_preview = st.slider("Rows to show", 10, 500, 50, 10)
    with fc3:
        sort_col = st.selectbox("Sort by", ["(none)"] + df.columns.tolist())

    preview = df.copy()
    if filter_county != "All" and "County" in preview.columns:
        preview = preview[preview["County"] == filter_county]
    if sort_col != "(none)":
        preview = preview.sort_values(sort_col, ascending=False)

    st.dataframe(preview.head(n_preview), use_container_width=True, height=400)
    st.caption(f"Showing {min(n_preview, len(preview)):,} of {len(preview):,} rows")

    # Quick numeric distribution
    st.markdown('<div class="section-header" style="margin-top:1rem">Numeric Column Distribution</div>',
                unsafe_allow_html=True)
    num_cols = df.select_dtypes(include=np.number).columns.tolist()
    if num_cols:
        dist_col = st.selectbox("Column", num_cols)
        try:
            import plotly.express as px
            fig_h = px.histogram(
                df, x=dist_col, nbins=50,
                color_discrete_sequence=[ENGINES["DuckDB"]["color"]],
            )
            fig_h.update_layout(
                paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                yaxis=dict(gridcolor="#1e2330", color="#6b7a99"),
                xaxis=dict(color="#6b7a99"),
                margin=dict(l=0, r=0, t=10, b=10),
                height=260, showlegend=False,
                font=dict(family="Syne"),
            )
            st.plotly_chart(fig_h, use_container_width=True)
        except ImportError:
            st.bar_chart(df[dist_col].value_counts().head(30))

# ══════════════════════════════════════════════════════════════════════════════════
# TAB 3 — SCHEMA & STATS
# ══════════════════════════════════════════════════════════════════════════════════
with tab_schema:
    st.markdown('<div class="section-header">Schema</div>', unsafe_allow_html=True)
    schema_rows = []
    for col in df.columns:
        null_pct = df[col].isna().mean() * 100
        uniq     = df[col].nunique()
        schema_rows.append({
            "Column":    col,
            "dtype":     str(df[col].dtype),
            "Non-Null %": f"{100-null_pct:.1f}%",
            "Unique":    f"{uniq:,}",
            "Sample":    str(df[col].dropna().iloc[0]) if not df[col].dropna().empty else "—",
        })
    st.dataframe(pd.DataFrame(schema_rows), use_container_width=True, hide_index=True)

    st.markdown('<div class="section-header" style="margin-top:1rem">Descriptive Statistics</div>',
                unsafe_allow_html=True)
    st.dataframe(df.describe().T, use_container_width=True)

    # Correlation
    num_df = df.select_dtypes(include=np.number)
    if len(num_df.columns) >= 2:
        st.markdown('<div class="section-header" style="margin-top:1rem">Correlation Matrix</div>',
                    unsafe_allow_html=True)
        try:
            import plotly.express as px
            corr = num_df.corr().round(2)
            fig_c = px.imshow(
                corr, text_auto=True, aspect="auto",
                color_continuous_scale="RdBu_r", zmin=-1, zmax=1,
            )
            fig_c.update_layout(
                paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                margin=dict(l=0, r=0, t=10, b=10),
                font=dict(family="Syne", color="#e8e8e8"),
                height=380,
            )
            st.plotly_chart(fig_c, use_container_width=True)
        except ImportError:
            st.dataframe(num_df.corr().round(3), use_container_width=True)

# ══════════════════════════════════════════════════════════════════════════════════
# TAB 4 — ENGINE GUIDE
# ══════════════════════════════════════════════════════════════════════════════════
with tab_guide:
    st.markdown('<div class="section-header">Engine Reference</div>', unsafe_allow_html=True)

    guide_data = [
        ("DuckDB",     "🦆", "pip install duckdb",
         "In-process OLAP engine. Blazing fast for analytical queries on DataFrames, CSVs, Parquet. Zero config.",
         "✅ Fastest for local analytics", "❌ Single-node only"),
        ("Polars",     "🐻‍❄️", "pip install polars",
         "Rust-powered DataFrame library with built-in SQL context. Excellent memory efficiency and parallelism.",
         "✅ Memory-efficient, Rust speed", "❌ SQL dialect differences"),
        ("SQLAlchemy", "🔗", "pip install sqlalchemy",
         "Python SQL toolkit and ORM. Works with any DB (SQLite, Postgres, MySQL, etc.) via dialect plugins.",
         "✅ Universal DB adapter", "❌ ORM overhead for bulk ops"),
        ("psycopg2",   "🐘", "pip install psycopg2-binary",
         "Native PostgreSQL adapter. Requires a running Postgres instance. Best for production PG workloads.",
         "✅ Native PG performance", "❌ Needs external Postgres"),
        ("PySpark",    "🔥", "pip install pyspark",
         "Apache Spark Python API. Distributed, handles terabyte-scale data across clusters. JVM startup overhead.",
         "✅ Scales to TB+, cluster-ready", "❌ JVM overhead, slow locally"),
        ("Dask-SQL",   "⚙️", "pip install dask-sql",
         "SQL layer on Dask DataFrames. Parallelises pandas operations across cores; cluster-friendly.",
         "✅ Familiar SQL on large CSVs", "❌ Less mature than Spark"),
    ]

    for name, icon, install, desc, pro, con in guide_data:
        cfg = ENGINES[name]
        with st.expander(f"{icon} {name}", expanded=False):
            gc1, gc2 = st.columns([2, 1])
            with gc1:
                st.markdown(f"**{desc}**")
                st.markdown(f"<span class='delta-good'>{pro}</span><br>"
                            f"<span class='delta-bad'>{con}</span>",
                            unsafe_allow_html=True)
            with gc2:
                st.markdown(f"""<div class="query-box">{install}</div>""",
                            unsafe_allow_html=True)

    st.divider()
    st.markdown('<div class="section-header">Choosing the Right Engine</div>',
                unsafe_allow_html=True)

    advice = {
        "Small–Medium data (<1 GB), single machine": "🦆 DuckDB or 🐻‍❄️ Polars",
        "Production app backed by PostgreSQL": "🐘 psycopg2 + 🔗 SQLAlchemy",
        "Multi-core laptop, data > RAM": "⚙️ Dask-SQL",
        "Cluster / Hadoop / cloud data lake (TB+)": "🔥 PySpark",
        "Exploratory analysis in notebook": "🦆 DuckDB or 🐻‍❄️ Polars",
        "ORM + migrations + schema management": "🔗 SQLAlchemy",
    }
    for scenario, recommendation in advice.items():
        st.markdown(
            f"**{scenario}** → {recommendation}"
        )
