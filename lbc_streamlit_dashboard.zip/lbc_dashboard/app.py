"""
LBC Mortality Rate — ML Dashboard
Streamlit app · run with:  streamlit run app.py
"""

import warnings
warnings.filterwarnings("ignore")

import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import seaborn as sns
from scipy import stats
import io, os, time

# ── sklearn ──────────────────────────────────────────────────────────────────
from sklearn.model_selection import (train_test_split, KFold,
                                     cross_val_predict)
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LinearRegression, Ridge, Lasso, ElasticNet
from sklearn.ensemble import (RandomForestRegressor, GradientBoostingRegressor,
                              BaggingRegressor)
from sklearn.svm import SVR
from sklearn.neighbors import KNeighborsRegressor
from sklearn.neural_network import MLPRegressor
from sklearn.inspection import permutation_importance
from sklearn.metrics import (mean_squared_error, mean_absolute_error,
                              r2_score, median_absolute_error)

try:
    from pygam import LinearGAM, s as gam_s
    HAS_GAM = True
except ImportError:
    HAS_GAM = False

try:
    import shap
    HAS_SHAP = True
except ImportError:
    HAS_SHAP = False

# ── Page config ───────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="LBC ML Dashboard",
    page_icon="🫁",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Shared style ──────────────────────────────────────────────────────────────
st.markdown("""
<style>
[data-testid="stSidebar"] { min-width: 280px; max-width: 340px; }
.metric-row { display:flex; gap:12px; margin-bottom:1rem; }
.kpi { background:#f0f2f6; border-radius:8px; padding:.75rem 1rem; flex:1; }
.kpi .val { font-size:1.6rem; font-weight:600; color:#0e1117; }
.kpi .lbl { font-size:.75rem; color:#6c757d; margin-top:2px; }
.section-tag { font-size:.7rem; font-weight:600; letter-spacing:.08em;
               text-transform:uppercase; color:#6c757d; margin-bottom:.5rem; }
div[data-testid="stExpander"] summary { font-weight:600; }
</style>
""", unsafe_allow_html=True)

SEED = 42

# ─── Helpers ─────────────────────────────────────────────────────────────────
def rmse(y, p):       return float(np.sqrt(mean_squared_error(y, p)))
def mape_safe(y, p):
    m = np.array(y) != 0
    return float(np.mean(np.abs((np.array(y)[m] - np.array(p)[m]) / np.array(y)[m])) * 100)

METRIC_FNS = {
    "RMSE":  rmse,
    "MAE":   lambda y,p: float(mean_absolute_error(y, p)),
    "R²":    lambda y,p: float(r2_score(y, p)),
    "MAPE":  mape_safe,
    "MedAE": lambda y,p: float(median_absolute_error(y, p)),
}

def evaluate(y_true, y_pred, metrics):
    return {m: round(METRIC_FNS[m](y_true, y_pred), 4) for m in metrics}

def make_pipe(name):
    reg_map = {
        "OLS":              LinearRegression(),
        "Ridge":            Ridge(alpha=1.0, random_state=SEED),
        "Lasso":            Lasso(alpha=0.1, max_iter=5000, random_state=SEED),
        "ElasticNet":       ElasticNet(alpha=0.1, l1_ratio=0.5, random_state=SEED),
        "Random Forest":    RandomForestRegressor(n_estimators=200, random_state=SEED, n_jobs=-1),
        "Gradient Boosting":GradientBoostingRegressor(n_estimators=200, learning_rate=0.05,
                                                      max_depth=4, random_state=SEED),
        "SVR":              SVR(kernel="rbf", C=10, epsilon=0.5),
        "k-NN":             KNeighborsRegressor(n_neighbors=10, weights="distance"),
        "Neural Net":       MLPRegressor(hidden_layer_sizes=(128,64), max_iter=500,
                                         random_state=SEED, early_stopping=True),
    }
    reg = reg_map[name]
    return Pipeline([("scaler", StandardScaler()), ("model", reg)])

VAR_COLORS = {
    "SMOKING": "#185FA5", "POVERTY": "#185FA5",
    "PM25": "#3B6D11", "NO2": "#3B6D11", "SO2": "#3B6D11",
    "Year": "#854F0B", "X": "#5F5E5A", "Y": "#5F5E5A",
}
VAR_CATEGORY = {
    "SMOKING":"Socioeconomic","POVERTY":"Socioeconomic",
    "PM25":"Environmental","NO2":"Environmental","SO2":"Environmental",
    "Year":"Temporal","X":"Spatial","Y":"Spatial",
}
SHAP_SIGN = {"SMOKING":1,"POVERTY":1,"PM25":1,"NO2":1,"SO2":1,"Year":-1,"X":-1,"Y":1}

plt.rcParams.update({"figure.dpi":120,"axes.spines.top":False,
                     "axes.spines.right":False,"axes.grid":True,"grid.alpha":0.3})

# ─── Sidebar: data & global settings ─────────────────────────────────────────
with st.sidebar:
    st.title("🫁 LBC Dashboard")
    st.caption("Lung & Bronchus Cancer mortality rate prediction")
    st.divider()

    st.markdown("**📂 Data source**")
    uploaded = st.file_uploader("Upload CSV", type=["csv"],
                                help="Must contain RATE column + feature columns")
    if uploaded:
        df_raw = pd.read_csv(uploaded)
        st.success(f"Loaded {df_raw.shape[0]:,} rows × {df_raw.shape[1]} cols")
    else:
        default_path = "data_1998_2010_long_lbc.csv"
        if os.path.exists(default_path):
            df_raw = pd.read_csv(default_path)
            st.info(f"Using default: `{default_path}`")
        else:
            st.warning("Upload a CSV to begin.")
            st.stop()

    st.divider()
    st.markdown("**🎯 Target & features**")
    all_cols = list(df_raw.columns)
    target = st.selectbox("Target column", all_cols,
                          index=all_cols.index("RATE") if "RATE" in all_cols else 0)
    id_cols_default = ["FIPS"] if "FIPS" in all_cols else []
    id_cols = st.multiselect("ID columns (drop before modelling)",
                              all_cols, default=id_cols_default)
    temporal_col = st.selectbox("Temporal column (None = absent)",
                                 ["None"] + all_cols,
                                 index=all_cols.index("Year")+1 if "Year" in all_cols else 0)
    temporal_col = None if temporal_col == "None" else temporal_col

    candidate_feats = [c for c in all_cols if c not in id_cols + [target]]
    default_feats = [c for c in ["SMOKING","POVERTY","PM25","NO2","SO2","Year"]
                     if c in candidate_feats]
    features = st.multiselect("Feature columns", candidate_feats,
                               default=default_feats or candidate_feats[:6])

    st.divider()
    st.markdown("**📅 Year filter**")
    if temporal_col and temporal_col in df_raw.columns:
        year_opts = ["All years", "Mean of all years"] + \
                    [str(y) for y in sorted(df_raw[temporal_col].unique())]
    else:
        year_opts = ["All years"]
    year_filter = st.selectbox("Filter", year_opts)
    st.divider()
    st.markdown("**⚙️ Global**")
    rand_seed = st.number_input("Random seed", value=42, step=1)
    SEED = int(rand_seed)
    fig_dpi = st.slider("Plot DPI", 80, 200, 120, step=20)
    plt.rcParams["figure.dpi"] = fig_dpi

# ─── Apply year filter ────────────────────────────────────────────────────────
@st.cache_data(show_spinner=False)
def apply_year_filter(data_hash, year_filter, temporal_col):
    # rebuilt when upstream changes; data_hash ensures cache invalidation
    return year_filter, temporal_col

if year_filter == "All years":
    df = df_raw.copy()
    filter_label = "All years"
elif year_filter == "Mean of all years":
    grp = [c for c in id_cols + (["X","Y"] if all(c in df_raw.columns for c in ["X","Y"]) else [])
           if c in df_raw.columns]
    df = df_raw.groupby(grp, as_index=False).mean(numeric_only=True) if grp else df_raw.mean(numeric_only=True).to_frame().T
    if temporal_col and temporal_col in df.columns:
        df = df.drop(columns=[temporal_col])
        if temporal_col in features:
            features = [f for f in features if f != temporal_col]
    filter_label = "Per-county means (all years)"
else:
    yr = int(year_filter)
    df = df_raw[df_raw[temporal_col] == yr].copy() if temporal_col else df_raw.copy()
    filter_label = f"Year = {yr}"

active_features = [f for f in features if f in df.columns]
X_full = df[active_features].dropna()
y_full = df.loc[X_full.index, target]

# ─── Navigation ──────────────────────────────────────────────────────────────
tabs = st.tabs(["📊 EDA", "✂️ Data split", "🔢 Covariates",
                "🤖 Models", "📏 Metrics", "🚀 Train & compare",
                "🌟 Variable importance"])

# ══════════════════════════════════════════════════════════════════════════════
# TAB 1 — EDA
# ══════════════════════════════════════════════════════════════════════════════
with tabs[0]:
    st.header("Exploratory data analysis")
    st.caption(f"Filter: **{filter_label}** · {len(df):,} rows · {len(active_features)} features")

    # KPI row
    c1,c2,c3,c4 = st.columns(4)
    c1.metric("Records in view", f"{len(df):,}")
    c2.metric(f"Mean {target}", f"{y_full.mean():.1f}")
    c3.metric(f"Std {target}", f"{y_full.std():.1f}")
    c4.metric("Features", len(active_features))
    st.divider()

    col_left, col_right = st.columns(2)

    with col_left:
        st.subheader(f"{target} distribution")
        chart_type = st.radio("Chart type", ["Histogram","Density","Box plot"],
                              horizontal=True, key="eda_chart")
        fig, ax = plt.subplots(figsize=(5,3))
        if chart_type == "Histogram":
            ax.hist(y_full.dropna(), bins=40, color="#378ADD", alpha=0.85,
                    edgecolor="white", linewidth=0.4)
            ax.set_xlabel(target); ax.set_ylabel("Count")
        elif chart_type == "Density":
            y_full.dropna().plot.kde(ax=ax, color="#378ADD", linewidth=2)
            ax.fill_between(ax.lines[0].get_xdata(), ax.lines[0].get_ydata(),
                            alpha=0.15, color="#378ADD")
            ax.set_xlabel(target)
        else:
            ax.boxplot(y_full.dropna(), vert=False, patch_artist=True,
                       boxprops=dict(facecolor="#B5D4F4", color="#185FA5"),
                       medianprops=dict(color="#185FA5", linewidth=2))
            ax.set_xlabel(target); ax.set_yticks([])
        ax.set_title(f"Distribution of {target}")
        st.pyplot(fig, use_container_width=True); plt.close(fig)

    with col_right:
        st.subheader(f"Correlation with {target}")
        corr_feats = [f for f in active_features if df[f].dtype in [float,int] and f in df.columns]
        corrs = df[corr_feats + [target]].corr()[target].drop(target).sort_values()
        fig, ax = plt.subplots(figsize=(5,3))
        colors = ["#3B6D11" if v > 0 else "#A32D2D" for v in corrs]
        ax.barh(corrs.index, corrs.values, color=colors)
        ax.axvline(0, color="black", linewidth=0.6)
        ax.set_title(f"Pearson r with {target}")
        ax.set_xlabel("Correlation")
        st.pyplot(fig, use_container_width=True); plt.close(fig)

    # Temporal trend
    if temporal_col and temporal_col in df.columns:
        st.subheader(f"{target} over time")
        trend = df.groupby(temporal_col)[target].mean().reset_index()
        fig, ax = plt.subplots(figsize=(10,3))
        ax.plot(trend[temporal_col], trend[target], marker="o",
                color="#185FA5", linewidth=2, markersize=4)
        ax.fill_between(trend[temporal_col], trend[target], alpha=0.1, color="#185FA5")
        ax.set_xlabel(temporal_col); ax.set_ylabel(f"Mean {target}")
        ax.set_title(f"Mean {target} by {temporal_col}")
        st.pyplot(fig, use_container_width=True); plt.close(fig)

    # Scatter explorer
    st.subheader("Scatter: covariate vs target")
    sc1, sc2, sc3 = st.columns([2,2,1])
    x_feat = sc1.selectbox("X axis", active_features, key="scatter_x")
    n_samp = sc3.select_slider("Sample", [200,500,1000,2000,5000], value=500)
    sample = df[[x_feat, target]].dropna().sample(min(n_samp, len(df)), random_state=SEED)
    fig, ax = plt.subplots(figsize=(9,3.5))
    ax.scatter(sample[x_feat], sample[target], alpha=0.3, s=10, color="#378ADD")
    m, b, r, *_ = stats.linregress(sample[x_feat], sample[target])
    xl = np.linspace(sample[x_feat].min(), sample[x_feat].max(), 100)
    ax.plot(xl, m*xl+b, color="#E24B4A", linewidth=1.5, linestyle="--",
            label=f"r = {r:.2f}")
    ax.legend(frameon=False); ax.set_xlabel(x_feat); ax.set_ylabel(target)
    ax.set_title(f"{x_feat} vs {target}  (n={len(sample):,})")
    st.pyplot(fig, use_container_width=True); plt.close(fig)

    # Descriptive stats
    st.subheader("Descriptive statistics")
    desc = df[active_features + [target]].describe().T.round(3)
    st.dataframe(desc, use_container_width=True)

    # Correlation heatmap
    with st.expander("Correlation heatmap"):
        corr_mat = df[active_features + [target]].corr()
        fig, ax = plt.subplots(figsize=(8,6))
        mask = np.triu(np.ones_like(corr_mat, dtype=bool))
        sns.heatmap(corr_mat, mask=mask, annot=True, fmt=".2f",
                    cmap="RdBu_r", center=0, vmin=-1, vmax=1,
                    ax=ax, linewidths=0.4, cbar_kws={"shrink":0.8})
        ax.set_title("Correlation matrix")
        st.pyplot(fig, use_container_width=True); plt.close(fig)

# ══════════════════════════════════════════════════════════════════════════════
# TAB 2 — DATA SPLIT
# ══════════════════════════════════════════════════════════════════════════════
with tabs[1]:
    st.header("Data splitting strategy")

    sp1, sp2 = st.columns([1,2])
    with sp1:
        strategy = st.radio("Strategy",
                            ["Random","Temporal","Spatial","K-Fold CV"],
                            help="Temporal avoids leakage by ordering by time.")
        train_f = st.slider("Train %", 50, 85, 70, 5) / 100
        val_f   = st.slider("Validation %", 5, 25, 15, 5) / 100
        test_f  = round(1 - train_f - val_f, 2)
        if strategy == "K-Fold CV":
            n_folds = st.slider("K folds", 3, 10, 5)
        st.metric("Test %", f"{test_f:.0%}")
        if test_f < 0:
            st.error("Train + Val > 100% — reduce sliders.")

    with sp2:
        n = len(X_full)
        n_tr = int(n * train_f)
        n_va = int(n * val_f)
        n_te = n - n_tr - n_va

        c1,c2,c3 = st.columns(3)
        c1.metric("Train records", f"{n_tr:,}", f"{train_f:.0%}")
        c2.metric("Validation records", f"{n_va:,}", f"{val_f:.0%}")
        c3.metric("Test records", f"{n_te:,}", f"{test_f:.0%}")

        # Visual split bar
        bar_html = f"""
        <div style="display:flex;height:28px;border-radius:6px;overflow:hidden;font-size:12px;font-weight:600;color:white">
          <div style="width:{train_f*100:.0f}%;background:#3B6D11;display:flex;align-items:center;justify-content:center">Train {train_f:.0%}</div>
          <div style="width:{val_f*100:.0f}%;background:#BA7517;display:flex;align-items:center;justify-content:center">Val {val_f:.0%}</div>
          <div style="width:{test_f*100:.0f}%;background:#E24B4A;display:flex;align-items:center;justify-content:center">Test {test_f:.0%}</div>
        </div>"""
        st.markdown(bar_html, unsafe_allow_html=True)
        st.caption("")

        # Temporal visualisation
        if temporal_col and temporal_col in df.columns and strategy == "Temporal":
            years_s = sorted(df[temporal_col].unique())
            n_yr = len(years_s)
            tr_cut = years_s[int(n_yr * train_f)]
            va_cut = years_s[int(n_yr * (train_f + val_f))]
            trend  = df.groupby(temporal_col)[target].mean().reset_index()
            fig, ax = plt.subplots(figsize=(8,3))
            for _, row in trend.iterrows():
                yr = row[temporal_col]
                c = "#3B6D11" if yr < tr_cut else "#BA7517" if yr < va_cut else "#E24B4A"
                ax.bar(yr, row[target], color=c, width=0.8)
            from matplotlib.patches import Patch
            ax.legend(handles=[Patch(color="#3B6D11",label="Train"),
                                Patch(color="#BA7517",label="Val"),
                                Patch(color="#E24B4A",label="Test")], frameon=False)
            ax.set_xlabel(temporal_col); ax.set_ylabel(f"Mean {target}")
            ax.set_title(f"Mean {target} by year — temporal split")
            st.pyplot(fig, use_container_width=True); plt.close(fig)
        elif temporal_col and temporal_col in df.columns:
            trend = df.groupby(temporal_col)[target].mean().reset_index()
            fig, ax = plt.subplots(figsize=(8,3))
            ax.bar(trend[temporal_col], trend[target], color="#B5D4F4", width=0.8)
            ax.set_xlabel(temporal_col); ax.set_ylabel(f"Mean {target}")
            ax.set_title(f"Mean {target} by {temporal_col}")
            st.pyplot(fig, use_container_width=True); plt.close(fig)

    # Store split config in session state
    st.session_state["split_cfg"] = dict(strategy=strategy, train_f=train_f,
                                          val_f=val_f, test_f=test_f,
                                          n_folds=n_folds if strategy=="K-Fold CV" else 5)

# ══════════════════════════════════════════════════════════════════════════════
# TAB 3 — COVARIATES
# ══════════════════════════════════════════════════════════════════════════════
with tabs[2]:
    st.header("Covariate selection")

    cv1, cv2 = st.columns([1,2])
    with cv1:
        preset = st.radio("Quick preset",
                          ["Custom","All","Environmental","Socioeconomic","No spatial"])
        env_feats   = [f for f in ["PM25","NO2","SO2"] if f in active_features]
        socio_feats = [f for f in ["SMOKING","POVERTY"] if f in active_features]
        spatial_feats = [f for f in ["X","Y"] if f in active_features]

        if preset == "All":
            default_sel = active_features
        elif preset == "Environmental":
            default_sel = env_feats
        elif preset == "Socioeconomic":
            default_sel = socio_feats
        elif preset == "No spatial":
            default_sel = [f for f in active_features if f not in spatial_feats]
        else:
            default_sel = active_features

        sel_features = st.multiselect("Select covariates", active_features,
                                       default=default_sel, key="cov_sel")

    with cv2:
        types = []
        if any(f in sel_features for f in socio_feats): types.append("Socioeconomic")
        if any(f in sel_features for f in env_feats):   types.append("Environmental")
        if any(f in sel_features for f in spatial_feats): types.append("Spatial")
        if "Year" in sel_features: types.append("Temporal")

        m1,m2 = st.columns(2)
        m1.metric("Selected features", len(sel_features))
        m2.metric("Feature types", " + ".join(types) if types else "none")

        if sel_features:
            corr_sel = df[sel_features + [target]].corr()[target].drop(target).abs().sort_values(ascending=True)
            fig, ax = plt.subplots(figsize=(6,max(2.5, len(sel_features)*0.4)))
            colors = [VAR_COLORS.get(f,"#888780") for f in corr_sel.index]
            ax.barh(corr_sel.index, corr_sel.values, color=colors)
            ax.set_xlim(0,1)
            ax.set_xlabel("|Pearson r| with target")
            ax.set_title("Variable importance (bivariate correlation)")
            st.pyplot(fig, use_container_width=True); plt.close(fig)

            st.subheader("Pair-plot sample")
            n_pairs = min(500, len(df))
            pair_sample = df[sel_features + [target]].dropna().sample(n_pairs, random_state=SEED)
            if len(sel_features) <= 5:
                fig = sns.pairplot(pair_sample, diag_kind="kde",
                                   plot_kws={"alpha":0.3,"s":6},
                                   diag_kws={"color":"#378ADD"},
                                   corner=True).fig
                st.pyplot(fig, use_container_width=True); plt.close(fig)
            else:
                st.info("Pair-plot shown for ≤5 features. Reduce selection to enable.")

    # Save to session
    st.session_state["sel_features"] = sel_features

# ══════════════════════════════════════════════════════════════════════════════
# TAB 4 — MODELS
# ══════════════════════════════════════════════════════════════════════════════
with tabs[3]:
    st.header("Model selection")

    BASE_MODELS = ["OLS","Ridge","Lasso","ElasticNet",
                   "Random Forest","Gradient Boosting",
                   "SVR","k-NN","Neural Net"] + (["GAM"] if HAS_GAM else [])

    st.subheader("Base models")
    cols = st.columns(3)
    selected_models = []
    for i, m in enumerate(BASE_MODELS):
        with cols[i % 3]:
            badge = {"OLS":"🟢 Fast","Ridge":"🟢 Fast","Lasso":"🟢 Fast",
                     "ElasticNet":"🟢 Fast","Random Forest":"🟡 Med",
                     "Gradient Boosting":"🔴 Slow","SVR":"🔴 Slow",
                     "k-NN":"🟡 Med","Neural Net":"🔴 Slow","GAM":"🟡 Med"}.get(m,"")
            if st.checkbox(f"{m}  {badge}", value=m in ["OLS","Ridge"], key=f"mdl_{m}"):
                selected_models.append(m)

    st.session_state["selected_models"] = selected_models
    st.caption(f"Selected: **{', '.join(selected_models) or 'none'}**")
    st.divider()

    # ── Ensemble builder ─────────────────────────────────────────────────────
    st.subheader("🔮 Ensemble model builder")
    ens_enabled = st.toggle("Enable ensemble stacking", value=False)

    if ens_enabled:
        e1, e2 = st.columns(2)
        with e1:
            ens_strategy = st.selectbox("Strategy",
                ["Stacking","Blending","Weighted averaging","Bagging","Boosting chain"])
            st.caption({
                "Stacking": "Meta-learner trained on out-of-fold predictions (most flexible).",
                "Blending": "Meta-learner trained on held-out validation set (faster).",
                "Weighted averaging": "Fixed weighted mean of base model outputs.",
                "Bagging": "Bootstrap aggregation — reduces variance.",
                "Boosting chain": "Each model corrects residuals of the previous.",
            }[ens_strategy])

            base_for_ens = st.multiselect("Base learners (≥2)",
                BASE_MODELS, default=["Ridge","Random Forest","Gradient Boosting"],
                key="ens_base")
            if len(base_for_ens) < 2:
                st.warning("Select at least 2 base learners.")

        with e2:
            META_LEARNERS = ["Linear Regression","Ridge","Lasso","ElasticNet",
                             "Random Forest","Gradient Boosting","Simple averaging"]
            meta_learner = st.selectbox("Meta-learner",
                META_LEARNERS if ens_strategy not in ["Weighted averaging","Bagging"]
                else ["N/A — no meta-learner"])

            if ens_strategy in ["Stacking","Blending"]:
                cv_folds_ens = st.slider("CV folds (OOF)", 3, 10, 5, key="ens_cv")
                use_orig_feats = st.toggle("Pass original features to meta-learner", True)
            if ens_strategy == "Weighted averaging":
                st.markdown("**Model weights**")
                weights = {}
                for bm in base_for_ens:
                    weights[bm] = st.slider(bm, 0, 100, 100//max(len(base_for_ens),1),
                                             key=f"w_{bm}")

        # Architecture diagram (text-based)
        if base_for_ens:
            diag_lines = ["```", "Input features"]
            diag_lines += [f"  → [{b}]" for b in base_for_ens]
            if ens_strategy not in ["Weighted averaging","Bagging"]:
                diag_lines += [f"      → [{meta_learner} meta-learner]"]
            else:
                agg = "Weighted avg" if ens_strategy == "Weighted averaging" else "Bootstrap avg"
                diag_lines += [f"      → [{agg}]"]
            diag_lines += ["          → RATE prediction", "```"]
            st.code("\n".join(diag_lines), language=None)

        st.session_state["ens_cfg"] = dict(
            enabled=True, strategy=ens_strategy,
            base_learners=base_for_ens,
            meta_learner=meta_learner,
            cv_folds=cv_folds_ens if ens_strategy in ["Stacking","Blending"] else 5,
            use_orig=use_orig_feats if ens_strategy in ["Stacking","Blending"] else False,
            weights=weights if ens_strategy=="Weighted averaging" else None,
        )
    else:
        st.session_state["ens_cfg"] = {"enabled": False}

    st.divider()
    st.subheader("Hyperparameter tuning")
    hp_strat = st.selectbox("HP strategy",
                             ["Default (no tuning)","Grid search","Random search","Bayesian opt."])
    if hp_strat != "Default (no tuning)":
        hp_iter = st.slider("Search iterations", 10, 100, 20, 10)

# ══════════════════════════════════════════════════════════════════════════════
# TAB 5 — METRICS
# ══════════════════════════════════════════════════════════════════════════════
with tabs[4]:
    st.header("Validation metrics")

    m1,m2 = st.columns(2)
    with m1:
        st.markdown("**Select metrics to compute**")
        use_rmse  = st.checkbox("RMSE — root mean squared error", True)
        use_mae   = st.checkbox("MAE — mean absolute error", True)
        use_r2    = st.checkbox("R² — coefficient of determination", True)
        use_mape  = st.checkbox("MAPE — mean absolute percentage error")
        use_medae = st.checkbox("MedAE — median absolute error")
    with m2:
        rank_by = st.radio("Primary ranking metric",
                           ["RMSE","MAE","R²","MAPE","MedAE"], index=0)
        eval_set = st.radio("Evaluate on", ["Validation set","Test set"])

    chosen_metrics = [m for m,v in [("RMSE",use_rmse),("MAE",use_mae),
                                     ("R²",use_r2),("MAPE",use_mape),
                                     ("MedAE",use_medae)] if v]
    st.session_state["metrics_cfg"] = dict(metrics=chosen_metrics,
                                            rank_by=rank_by, eval_set=eval_set)

    st.divider()
    st.subheader("Metric descriptions")
    metric_info = {
        "RMSE": "Penalises large errors heavily. Same units as the target. Lower = better.",
        "MAE":  "Average absolute error. Robust to outliers. Lower = better.",
        "R²":   "Proportion of variance explained. 1.0 = perfect fit. Higher = better.",
        "MAPE": "Scale-independent percentage error. Lower = better. Undefined if target = 0.",
        "MedAE":"Median absolute error. Very robust to outliers. Lower = better.",
    }
    for m, desc in metric_info.items():
        if m in chosen_metrics:
            st.markdown(f"**{m}** — {desc}")

# ══════════════════════════════════════════════════════════════════════════════
# TAB 6 — TRAIN & COMPARE
# ══════════════════════════════════════════════════════════════════════════════
with tabs[5]:
    st.header("Train & compare models")

    # Pull configs from session state
    split_cfg   = st.session_state.get("split_cfg", {"strategy":"Random","train_f":0.7,"val_f":0.15,"test_f":0.15,"n_folds":5})
    ens_cfg     = st.session_state.get("ens_cfg",   {"enabled":False})
    metrics_cfg = st.session_state.get("metrics_cfg", {"metrics":["RMSE","MAE","R²"],"rank_by":"RMSE","eval_set":"Validation set"})
    sel_features_train = st.session_state.get("sel_features", active_features)
    sel_models  = st.session_state.get("selected_models", ["OLS","Ridge"])

    Xt = df[sel_features_train].dropna()
    yt = df.loc[Xt.index, target]

    st.info(f"**{filter_label}** · {len(Xt):,} records · {len(sel_features_train)} features · {len(sel_models)} base model(s)" +
            (" + Ensemble" if ens_cfg.get("enabled") else ""))

    if not sel_models:
        st.warning("Go to **Models** tab and select at least one model.")
    elif not sel_features_train:
        st.warning("Go to **Covariates** tab and select at least one feature.")
    elif st.button("▶  Run selected models", type="primary", use_container_width=True):

        # ── Build splits ─────────────────────────────────────────────────────
        strat = split_cfg["strategy"]
        tf, vf = split_cfg["train_f"], split_cfg["val_f"]

        if strat == "Temporal" and temporal_col and temporal_col in df.columns:
            years_all = sorted(df.loc[Xt.index, temporal_col].unique())
            ny = len(years_all)
            tr_cut = years_all[int(ny*tf)]
            va_cut = years_all[int(ny*(tf+vf))]
            idx = Xt.index
            yr_ser = df.loc[idx, temporal_col]
            tr_i = idx[yr_ser < tr_cut]
            va_i = idx[(yr_ser >= tr_cut) & (yr_ser < va_cut)]
            te_i = idx[yr_ser >= va_cut]
            X_train,y_train = Xt.loc[tr_i], yt.loc[tr_i]
            X_val,  y_val   = Xt.loc[va_i], yt.loc[va_i]
            X_test, y_test  = Xt.loc[te_i], yt.loc[te_i]
        elif strat == "K-Fold CV":
            X_rest, X_test, y_rest, y_test = train_test_split(
                Xt, yt, test_size=0.2, random_state=SEED)
            X_train,X_val,y_train,y_val = X_rest,X_rest,y_rest,y_rest
        else:
            X_tv, X_test, y_tv, y_test = train_test_split(
                Xt, yt, test_size=split_cfg["test_f"], random_state=SEED)
            vs = vf / (tf+vf)
            X_train, X_val, y_train, y_val = train_test_split(
                X_tv, y_tv, test_size=vs, random_state=SEED)

        eval_X = X_val if metrics_cfg["eval_set"]=="Validation set" else X_test
        eval_y = y_val if metrics_cfg["eval_set"]=="Validation set" else y_test

        # ── Train models ─────────────────────────────────────────────────────
        results, trained = {}, {}
        prog = st.progress(0, text="Training models…")
        n_total = len(sel_models) + (1 if ens_cfg.get("enabled") else 0)

        for i, mname in enumerate(sel_models):
            prog.progress((i+0.5)/n_total, text=f"Training {mname}…")
            if mname == "GAM":
                if not HAS_GAM:
                    st.warning("PyGAM not installed — skipping GAM."); continue
                sc = StandardScaler()
                Xt_tr = sc.fit_transform(X_train)
                terms  = sum(gam_s(j) for j in range(Xt_tr.shape[1]))
                mdl = LinearGAM(terms).fit(Xt_tr, y_train)
                class _W:
                    def __init__(self,g,s): self.g,self.s=g,s
                    def predict(self,X): return self.g.predict(self.s.transform(X))
                trained[mname] = _W(mdl, sc)
            else:
                pipe = make_pipe(mname)
                pipe.fit(X_train, y_train)
                trained[mname] = pipe

            preds = trained[mname].predict(eval_X)
            results[mname] = evaluate(eval_y, preds, metrics_cfg["metrics"])
            prog.progress((i+1)/n_total, text=f"{mname} done.")

        # ── Ensemble ─────────────────────────────────────────────────────────
        ens_name = None
        if ens_cfg.get("enabled") and len(ens_cfg.get("base_learners",[])) >= 2:
            prog.progress((n_total-0.5)/n_total, text="Building ensemble…")
            bl = [b for b in ens_cfg["base_learners"] if b in trained]
            estrat = ens_cfg["strategy"]

            if estrat in ("Stacking","Blending"):
                if estrat == "Stacking":
                    kf_e = KFold(n_splits=ens_cfg["cv_folds"], shuffle=True, random_state=SEED)
                    meta_tr = np.zeros((len(X_train), len(bl)))
                    for j,bn in enumerate(bl):
                        meta_tr[:,j] = cross_val_predict(make_pipe(bn), X_train, y_train, cv=kf_e, n_jobs=-1)
                    y_meta = y_train.values
                else:
                    meta_tr = np.column_stack([trained[b].predict(X_val) for b in bl])
                    y_meta  = y_val.values

                if ens_cfg.get("use_orig"):
                    sc_orig = StandardScaler()
                    orig_tr = sc_orig.fit_transform(X_train if estrat=="Stacking" else X_val)
                    meta_tr = np.hstack([meta_tr, orig_tr])

                meta_map = {"Linear Regression":LinearRegression(),"Ridge":Ridge(1.0),
                            "Lasso":Lasso(0.05),"ElasticNet":ElasticNet(0.05),
                            "Random Forest":RandomForestRegressor(100,random_state=SEED),
                            "Gradient Boosting":GradientBoostingRegressor(100,random_state=SEED),
                            "Simple averaging":None}
                meta_reg = meta_map.get(ens_cfg.get("meta_learner","Ridge"), Ridge(1.0))
                if meta_reg is not None:
                    meta_reg.fit(meta_tr, y_meta)

                def ens_pred(X_in):
                    bp = np.column_stack([trained[b].predict(X_in) for b in bl])
                    if ens_cfg.get("use_orig"): bp=np.hstack([bp,sc_orig.transform(X_in)])
                    return meta_reg.predict(bp) if meta_reg else bp.mean(1)

            elif estrat == "Weighted averaging":
                w = ens_cfg.get("weights") or {b:1 for b in bl}
                wsum = sum(w.get(b,1) for b in bl) or 1
                def ens_pred(X_in):
                    return sum(w.get(b,1)*trained[b].predict(X_in) for b in bl) / wsum
            elif estrat == "Bagging":
                base_pipe = make_pipe(bl[0])
                bag = BaggingRegressor(estimator=base_pipe.named_steps["model"],
                                       n_estimators=30, random_state=SEED, n_jobs=-1)
                sc_bag = StandardScaler()
                bag.fit(sc_bag.fit_transform(X_train), y_train)
                def ens_pred(X_in): return bag.predict(sc_bag.transform(X_in))
            else:
                def ens_pred(X_in):
                    return np.mean([trained[b].predict(X_in) for b in bl], axis=0)

            ens_name = f"Ensemble ({estrat})"
            ens_preds = ens_pred(eval_X)
            results[ens_name] = evaluate(eval_y, ens_preds, metrics_cfg["metrics"])
            trained[ens_name] = type("EnsModel",(object,),{"predict":staticmethod(ens_pred)})()
            prog.progress(1.0, text="Ensemble done.")

        prog.empty()
        st.session_state["train_results"] = results
        st.session_state["trained_models"] = trained
        st.session_state["eval_data"]      = (eval_X, eval_y)
        st.session_state["ens_name"]       = ens_name

        st.success(f"✅ Trained {len(results)} model(s) successfully.")

    # ── Show results ─────────────────────────────────────────────────────────
    if "train_results" in st.session_state:
        results  = st.session_state["train_results"]
        trained  = st.session_state["trained_models"]
        eval_X, eval_y = st.session_state["eval_data"]
        ens_name = st.session_state.get("ens_name")
        rank_by  = metrics_cfg["rank_by"]
        metrics  = metrics_cfg["metrics"]

        res_df = pd.DataFrame(results).T.reset_index().rename(columns={"index":"Model"})
        asc = rank_by != "R²"
        res_sorted = res_df.sort_values(rank_by, ascending=asc).reset_index(drop=True)
        best_name = res_sorted.iloc[0]["Model"]

        # KPI row
        c1,c2,c3,c4 = st.columns(4)
        c1.metric("Best model", best_name)
        if rank_by in res_sorted.columns:
            c2.metric(f"Best {rank_by}", f"{res_sorted.iloc[0][rank_by]:.4f}")
        c3.metric("Models trained", len(results))
        if ens_name and ens_name in results:
            best_base = res_sorted[~res_sorted["Model"].str.startswith("Ensemble")].iloc[0]
            diff = results[ens_name].get(rank_by,0) - best_base.get(rank_by,0)
            c4.metric("Ensemble vs best base", f"{abs(diff):.4f}",
                      delta=f"{'↓' if (diff<0 and asc) or (diff>0 and not asc) else '↑'} {'better' if (diff<0 and asc) or (diff>0 and not asc) else 'worse'}")

        st.divider()

        # Comparison charts
        col_l, col_r = st.columns(2)
        with col_l:
            st.subheader("RMSE comparison")
            if "RMSE" in res_sorted.columns:
                sub = res_sorted.sort_values("RMSE")
                colors = ["#534AB7" if "Ensemble" in str(m)
                          else "#3B6D11" if i==0 else "#B5D4F4"
                          for i,m in enumerate(sub["Model"])]
                fig,ax = plt.subplots(figsize=(5,max(3,len(sub)*0.4)))
                ax.barh(sub["Model"], sub["RMSE"], color=colors)
                ax.set_xlabel("RMSE"); ax.set_title("RMSE (lower = better)")
                ax.invert_yaxis()
                st.pyplot(fig, use_container_width=True); plt.close(fig)

        with col_r:
            st.subheader("R² comparison")
            if "R²" in res_sorted.columns:
                sub = res_sorted.sort_values("R²", ascending=False)
                colors = ["#534AB7" if "Ensemble" in str(m)
                          else "#3B6D11" if i==0 else "#B5D4F4"
                          for i,m in enumerate(sub["Model"])]
                fig,ax = plt.subplots(figsize=(5,max(3,len(sub)*0.4)))
                ax.barh(sub["Model"], sub["R²"], color=colors)
                ax.set_xlabel("R²"); ax.set_title("R² (higher = better)")
                ax.set_xlim(max(0, res_sorted["R²"].min()-0.05), 1.01)
                ax.invert_yaxis()
                st.pyplot(fig, use_container_width=True); plt.close(fig)

        # Full results table
        st.subheader("Full results table")
        styled = res_sorted.set_index("Model")
        st.dataframe(styled.style.format("{:.4f}").highlight_min(
            subset=[c for c in metrics if c != "R²"], color="#EAF3DE"
        ).highlight_max(
            subset=[c for c in metrics if c == "R²"], color="#EAF3DE"
        ), use_container_width=True)

        # Predicted vs actual
        st.subheader(f"Predicted vs actual — {best_name}")
        best_preds = trained[best_name].predict(eval_X)
        residuals  = eval_y.values - best_preds
        fig, axes = plt.subplots(1,2, figsize=(11,4))
        lo = min(eval_y.min(), best_preds.min())
        hi = max(eval_y.max(), best_preds.max())
        axes[0].scatter(eval_y, best_preds, alpha=0.3, s=8, color="#378ADD")
        axes[0].plot([lo,hi],[lo,hi],"r--",linewidth=1.2,label="Perfect fit")
        axes[0].set_xlabel(f"Actual {target}"); axes[0].set_ylabel(f"Predicted {target}")
        axes[0].set_title("Predicted vs actual"); axes[0].legend(frameon=False)
        axes[1].hist(residuals, bins=50, color="#378ADD", alpha=0.8, edgecolor="white", linewidth=0.3)
        axes[1].axvline(0, color="#E24B4A", linewidth=1.5, linestyle="--")
        axes[1].set_xlabel("Residual"); axes[1].set_ylabel("Count")
        axes[1].set_title("Residual distribution")
        plt.tight_layout()
        st.pyplot(fig, use_container_width=True); plt.close(fig)

        st.caption(f"Bias (mean residual): {residuals.mean():.3f} · Std: {residuals.std():.3f}")

        # Download
        csv_buf = io.StringIO()
        res_sorted.to_csv(csv_buf, index=False)
        st.download_button("⬇  Download results CSV", csv_buf.getvalue(),
                           "model_results.csv","text/csv")

# ══════════════════════════════════════════════════════════════════════════════
# TAB 7 — VARIABLE IMPORTANCE
# ══════════════════════════════════════════════════════════════════════════════
with tabs[6]:
    st.header("Variable importance")

    trained   = st.session_state.get("trained_models", {})
    eval_data = st.session_state.get("eval_data", (None,None))
    eval_X_vi, eval_y_vi = eval_data

    if not trained or eval_X_vi is None:
        st.info("Run models first in **Train & compare** to unlock all importance methods.")

    vi1, vi2, vi3 = st.columns(3)
    vi_method = vi1.selectbox("Method",
        ["Pearson |r|","Permutation importance","Coefficient magnitude",
         "Gini / impurity","SHAP values"])
    vi_model  = vi2.selectbox("Model",
        ["Best model"] + list(trained.keys()) if trained else ["Best model"])
    vi_sort   = vi3.selectbox("Sort", ["By importance","Alphabetical","By category"])

    # Resolve model
    if trained:
        results = st.session_state.get("train_results",{})
        rank_by_vi = st.session_state.get("metrics_cfg",{}).get("rank_by","RMSE")
        asc_vi = rank_by_vi != "R²"
        if vi_model == "Best model" and results:
            best_vi = sorted(results, key=lambda m: results[m].get(rank_by_vi,0),
                             reverse=not asc_vi)[0]
            vi_model_resolved = best_vi
        else:
            vi_model_resolved = vi_model
    else:
        vi_model_resolved = None

    feat_cols_vi = eval_X_vi.columns.tolist() if eval_X_vi is not None else active_features

    # ── Compute importance ────────────────────────────────────────────────────
    imp_series = None

    if vi_method == "Pearson |r|":
        imp_values = {}
        for f in feat_cols_vi:
            mask_ = df[f].notna() & df[target].notna()
            if mask_.sum() > 5:
                r_, _ = stats.pearsonr(df.loc[mask_,f], df.loc[mask_,target])
                imp_values[f] = abs(r_)
        imp_series = pd.Series(imp_values, name="Importance")

    elif vi_method == "Permutation importance" and vi_model_resolved and vi_model_resolved in trained:
        with st.spinner("Computing permutation importance…"):
            pipe_vi = trained[vi_model_resolved]
            perm = permutation_importance(pipe_vi, eval_X_vi, eval_y_vi,
                                          n_repeats=10, random_state=SEED, n_jobs=-1)
        imp_series = pd.Series(perm.importances_mean, index=feat_cols_vi, name="Importance")

    elif vi_method == "Coefficient magnitude" and vi_model_resolved and vi_model_resolved in trained:
        pipe_vi = trained[vi_model_resolved]
        if hasattr(pipe_vi, "named_steps") and hasattr(pipe_vi.named_steps.get("model",""), "coef_"):
            coef = np.abs(pipe_vi.named_steps["model"].coef_)
            imp_series = pd.Series(coef, index=feat_cols_vi, name="Importance")
        else:
            st.warning(f"{vi_model_resolved} has no linear coefficients. Try a linear model.")

    elif vi_method == "Gini / impurity" and vi_model_resolved and vi_model_resolved in trained:
        pipe_vi = trained[vi_model_resolved]
        if hasattr(pipe_vi, "named_steps") and hasattr(pipe_vi.named_steps.get("model",""), "feature_importances_"):
            fi = pipe_vi.named_steps["model"].feature_importances_
            imp_series = pd.Series(fi, index=feat_cols_vi, name="Importance")
        else:
            st.warning(f"{vi_model_resolved} is not a tree model. Try Random Forest or GBM.")

    elif vi_method == "SHAP values" and vi_model_resolved and vi_model_resolved in trained:
        if not HAS_SHAP:
            st.warning("Install SHAP: `pip install shap`")
        else:
            with st.spinner("Computing SHAP values…"):
                pipe_vi = trained[vi_model_resolved]
                if hasattr(pipe_vi,"named_steps"):
                    Xt_shap = pipe_vi.named_steps["scaler"].transform(eval_X_vi)
                    inner   = pipe_vi.named_steps["model"]
                    try:
                        if isinstance(inner,(RandomForestRegressor,GradientBoostingRegressor)):
                            explainer = shap.TreeExplainer(inner)
                        else:
                            explainer = shap.LinearExplainer(inner, Xt_shap)
                        shap_vals = explainer.shap_values(Xt_shap)
                        imp_series = pd.Series(np.abs(shap_vals).mean(0),
                                               index=feat_cols_vi, name="Importance")
                        st.subheader("SHAP summary plot")
                        fig2, ax2 = plt.subplots(figsize=(8,4))
                        shap.summary_plot(shap_vals, Xt_shap,
                                          feature_names=feat_cols_vi,
                                          show=False, plot_size=None, ax=ax2)
                        st.pyplot(fig2, use_container_width=True); plt.close(fig2)
                    except Exception as e:
                        st.error(f"SHAP failed: {e}")

    # ── Plot importance bars ──────────────────────────────────────────────────
    if imp_series is not None:
        imp_series = imp_series.dropna()
        if vi_sort == "By importance":
            imp_sorted = imp_series.sort_values(ascending=True)
        elif vi_sort == "Alphabetical":
            imp_sorted = imp_series.sort_index()
        else:
            order = sorted(imp_series.index, key=lambda f: (VAR_CATEGORY.get(f,"z"),f))
            imp_sorted = imp_series.loc[order]

        fig, ax = plt.subplots(figsize=(8, max(3, len(imp_sorted)*0.4)))
        colors = [VAR_COLORS.get(f,"#888780") for f in imp_sorted.index]
        bars = ax.barh(imp_sorted.index, imp_sorted.values, color=colors)
        ax.set_xlabel("Importance"); ax.set_title(f"Variable importance — {vi_method}")
        # legend
        from matplotlib.patches import Patch
        legend_els = [Patch(color=v,label=k) for k,v in
                      {"Socioeconomic":"#185FA5","Environmental":"#3B6D11",
                       "Temporal":"#854F0B","Spatial":"#5F5E5A"}.items()
                      if any(VAR_COLORS.get(f)==v for f in imp_sorted.index)]
        if legend_els:
            ax.legend(handles=legend_els, frameon=False, loc="lower right", fontsize=9)
        st.pyplot(fig, use_container_width=True); plt.close(fig)

        # SHAP directional bars
        st.subheader("Directional effects (SHAP-style)")
        imp_desc = imp_sorted.sort_values(ascending=False)
        max_val  = imp_desc.max() or 1
        mid_px   = 140
        rows_html = ""
        for feat, val in imp_desc.items():
            direction = SHAP_SIGN.get(feat, 1)
            bar_w = int(val / max_val * mid_px)
            shap_val_disp = f"{direction*val*0.3:+.3f}"
            color = "#97C459" if direction > 0 else "#F09595"
            arrow = "↑ increases target" if direction > 0 else "↓ decreases target"
            cat_color = VAR_COLORS.get(feat,"#888780")
            if direction > 0:
                bar_html_d = f'<div style="width:{mid_px}px"></div><div style="width:1px;background:#ddd;height:18px"></div><div style="width:{bar_w}px;background:{color};border-radius:3px 0 0 3px;display:flex;align-items:center;padding-left:4px"><span style="font-size:11px;font-weight:600;color:white">{shap_val_disp}</span></div>'
            else:
                bar_html_d = f'<div style="width:{mid_px-bar_w}px"></div><div style="width:{bar_w}px;background:{color};border-radius:0 3px 3px 0;display:flex;align-items:center;justify-content:flex-end;padding-right:4px"><span style="font-size:11px;font-weight:600;color:white">{shap_val_disp}</span></div><div style="width:1px;background:#ddd;height:18px"></div>'
            rows_html += f'<div style="display:flex;align-items:center;gap:8px;margin-bottom:6px"><span style="min-width:80px;font-size:13px;font-weight:500;text-align:right">{feat}</span><div style="display:flex;align-items:center;gap:0">{bar_html_d}</div><span style="font-size:11px;color:#888;margin-left:8px">{arrow}</span><span style="width:8px;height:8px;border-radius:50%;background:{cat_color};display:inline-block;margin-left:auto"></span></div>'
        st.markdown(rows_html, unsafe_allow_html=True)

        # Heatmap across models
        if len(trained) >= 2:
            st.subheader("Importance comparison across models")
            heat_data = {}
            for mname, mpipe in list(trained.items())[:6]:
                if vi_method == "Pearson |r|":
                    heat_data[mname] = imp_series
                elif vi_method == "Permutation importance":
                    try:
                        pr = permutation_importance(mpipe, eval_X_vi, eval_y_vi,
                                                    n_repeats=5, random_state=SEED, n_jobs=-1)
                        heat_data[mname] = pd.Series(pr.importances_mean, index=feat_cols_vi)
                    except: pass
                elif vi_method in ("Coefficient magnitude","Gini / impurity"):
                    if hasattr(mpipe,"named_steps"):
                        inner = mpipe.named_steps.get("model","")
                        attr  = "coef_" if vi_method=="Coefficient magnitude" else "feature_importances_"
                        if hasattr(inner, attr):
                            heat_data[mname] = pd.Series(np.abs(getattr(inner,attr)), index=feat_cols_vi)
            if heat_data:
                heat_df = pd.DataFrame(heat_data).fillna(0)
                fig, ax = plt.subplots(figsize=(min(12, len(heat_df.columns)*1.8),
                                                max(3, len(feat_cols_vi)*0.5)))
                sns.heatmap(heat_df, annot=True, fmt=".3f", cmap="Blues",
                            ax=ax, linewidths=0.3, cbar_kws={"shrink":0.7})
                ax.set_title("Feature importance heatmap across models")
                st.pyplot(fig, use_container_width=True); plt.close(fig)

    # Year-by-year stability
    if temporal_col and temporal_col in df_raw.columns:
        st.divider()
        st.subheader("Importance stability across years")
        stab_feat = st.selectbox("Feature to track", feat_cols_vi, key="stab_feat")
        yr_corrs  = {}
        for yr in sorted(df_raw[temporal_col].unique()):
            sub = df_raw[df_raw[temporal_col]==yr]
            mask_ = sub[stab_feat].notna() & sub[target].notna()
            if mask_.sum() > 5:
                r_,_ = stats.pearsonr(sub.loc[mask_,stab_feat], sub.loc[mask_,target])
                yr_corrs[yr] = abs(r_)
        if yr_corrs:
            stab_s = pd.Series(yr_corrs)
            fig, ax = plt.subplots(figsize=(10,3))
            ax.plot(stab_s.index, stab_s.values, marker="o",
                    color=VAR_COLORS.get(stab_feat,"#378ADD"), linewidth=2, markersize=5)
            ax.fill_between(stab_s.index, stab_s.values, alpha=0.12,
                            color=VAR_COLORS.get(stab_feat,"#378ADD"))
            ax.set_ylim(0,1); ax.set_xlabel(temporal_col)
            ax.set_ylabel("|Pearson r|")
            ax.set_title(f"Importance of {stab_feat} over time")
            st.pyplot(fig, use_container_width=True); plt.close(fig)
